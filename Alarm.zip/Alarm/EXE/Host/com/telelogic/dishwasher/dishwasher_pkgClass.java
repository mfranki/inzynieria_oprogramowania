/*********************************************************************
	Rhapsody	: 8.3.1
	Login		: student
	Component	: EXE
	Configuration 	: Host
	Model Element	: com.telelogic.dishwasher
//!	Generated Date	: Tue, 16, Apr 2019 
	File Path	: EXE/Host/com/telelogic/dishwasher/dishwasher_pkgClass.java
*********************************************************************/

package com.telelogic.dishwasher;

//## auto_generated
import com.telelogic.*;

//----------------------------------------------------------------------------
// com/telelogic/dishwasher/dishwasher_pkgClass.java                                                                  
//----------------------------------------------------------------------------

//## package com::telelogic::dishwasher 


//## ignore 
public class dishwasher_pkgClass {
    
}
/*********************************************************************
	File Path	: EXE/Host/com/telelogic/dishwasher/dishwasher_pkgClass.java
*********************************************************************/

