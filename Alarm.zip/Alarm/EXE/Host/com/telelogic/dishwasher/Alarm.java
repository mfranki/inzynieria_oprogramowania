/*********************************************************************
	Rhapsody	: 8.3.1
	Login		: student
	Component	: EXE
	Configuration 	: Host
	Model Element	: Alarm
//!	Generated Date	: Sun, 2, Jun 2019 
	File Path	: EXE/Host/com/telelogic/dishwasher/Alarm.java
*********************************************************************/

package com.telelogic.dishwasher;

//## auto_generated
import com.ibm.rational.rhapsody.oxf.*;
//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.states.*;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// com/telelogic/dishwasher/Alarm.java                                                                  
//----------------------------------------------------------------------------

//## package com::telelogic::dishwasher 


//## class Alarm 
public class Alarm implements RiJStateConcept, Animated {
    
    //#[ ignore
    // Instrumentation attributes (Animation)
    private Animate animate;
    
    public static AnimClass animClassAlarm = new AnimClass("com.telelogic.dishwasher.Alarm",false);
    //#]
    
    public Reactive reactive;		//## ignore 
    
    protected boolean armingDone;		//## attribute armingDone 
    
    protected int armingProgress;		//## attribute armingProgress 
    
    protected static int codeState;		//## attribute codeState 
    
    protected static int state;		//## attribute state 
    
    protected Display itsDisplay;		//## link itsDisplay 
    
    //#[ ignore 
    public static final int RiJNonState=0;
    public static final int SystemSetup=1;
    public static final int InfoDisp=2;
    public static final int IncorrectCharacter=3;
    public static final int Disarmed=4;
    public static final int digit3=5;
    public static final int digit2=6;
    public static final int digit1=7;
    public static final int Arming=8;
    public static final int Armed=9;
    public static final int Active=10;
    //#]
    protected int rootState_subState;		//## ignore 
    
    protected int rootState_active;		//## ignore 
    
    public static final int Alarm_Timeout_Arming_id = 1;		//## ignore 
    
    
    //## statechart_method 
    public RiJThread getThread() {
        return reactive.getThread();
    }
    
    //## statechart_method 
    public void schedTimeout(long delay, long tmID, RiJStateReactive reactive) {
        getThread().schedTimeout(delay, tmID, reactive);
    }
    
    //## statechart_method 
    public void unschedTimeout(long tmID, RiJStateReactive reactive) {
        getThread().unschedTimeout(tmID, reactive);
    }
    
    //## statechart_method 
    public boolean isIn(int state) {
        return reactive.isIn(state);
    }
    
    //## statechart_method 
    public boolean isCompleted(int state) {
        return reactive.isCompleted(state);
    }
    
    //## statechart_method 
    public RiJEventConsumer getEventConsumer() {
        return (RiJEventConsumer)reactive;
    }
    
    //## statechart_method 
    public void gen(RiJEvent event) {
        reactive._gen(event);
    }
    
    //## statechart_method 
    public void queueEvent(RiJEvent event) {
        reactive.queueEvent(event);
    }
    
    //## statechart_method 
    public int takeEvent(RiJEvent event) {
        return reactive.takeEvent(event);
    }
    
    // Constructors
    
    //## auto_generated 
    public  Alarm(RiJThread p_thread) {
        try {
            animInstance().notifyConstructorEntered(animClassAlarm.getUserClass(),
               new ArgData[] {
               });
        
        reactive = new Reactive(p_thread);
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation setup() 
    public void setup() {
        try {
            animInstance().notifyMethodEntered("setup",
               new ArgData[] {
               });
        
        //#[ operation setup() 
        state = 1;      
        codeState=0;
        armingDone = false;  
        
        for(int i=0; i<500; i++)
        	System.out.println("");
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## auto_generated 
    public boolean getArmingDone() {
        return armingDone;
    }
    
    //## auto_generated 
    public void setArmingDone(boolean p_armingDone) {
        armingDone = p_armingDone;
    }
    
    //## auto_generated 
    public int getArmingProgress() {
        return armingProgress;
    }
    
    //## auto_generated 
    public void setArmingProgress(int p_armingProgress) {
        armingProgress = p_armingProgress;
    }
    
    //## auto_generated 
    public static int getCodeState() {
        return codeState;
    }
    
    //## auto_generated 
    public static void setCodeState(int p_codeState) {
        codeState = p_codeState;
    }
    
    //## auto_generated 
    public static int getState() {
        return state;
    }
    
    //## auto_generated 
    public static void setState(int p_state) {
        state = p_state;
    }
    
    //## auto_generated 
    public Display getItsDisplay() {
        return itsDisplay;
    }
    
    //## auto_generated 
    public void __setItsDisplay(Display p_Display) {
        itsDisplay = p_Display;
        if(p_Display != null)
            {
                animInstance().notifyRelationAdded("itsDisplay", p_Display);
            }
        else
            {
                animInstance().notifyRelationCleared("itsDisplay");
            }
    }
    
    //## auto_generated 
    public void _setItsDisplay(Display p_Display) {
        if(itsDisplay != null)
            {
                itsDisplay.__setItsAlarm(null);
            }
        __setItsDisplay(p_Display);
    }
    
    //## auto_generated 
    public void setItsDisplay(Display p_Display) {
        if(p_Display != null)
            {
                p_Display._setItsAlarm(this);
            }
        _setItsDisplay(p_Display);
    }
    
    //## auto_generated 
    public void _clearItsDisplay() {
        animInstance().notifyRelationCleared("itsDisplay");
        itsDisplay = null;
    }
    
    //## auto_generated 
    public boolean startBehavior() {
        boolean done = false;
        done = reactive.startBehavior();
        return done;
    }
    
    //## ignore 
    public class Reactive extends RiJStateReactive implements AnimatedReactive {
        
        // Default constructor 
        public Reactive() {
            this(RiJMainThread.instance());
        }
        
        
        // Constructors
        
        public  Reactive(RiJThread p_thread) {
            super(p_thread);
            initStatechart();
        }
        
        //## statechart_method 
        public boolean isIn(int state) {
            if(rootState_subState == state)
                {
                    return true;
                }
            return false;
        }
        
        //## statechart_method 
        public boolean isCompleted(int state) {
            return true;
        }
        
        //## statechart_method 
        public void rootState_add(AnimStates animStates) {
            animStates.add("ROOT");
            switch (rootState_subState) {
                case Disarmed:
                {
                    Disarmed_add(animStates);
                }
                break;
                case Armed:
                {
                    Armed_add(animStates);
                }
                break;
                case Active:
                {
                    Active_add(animStates);
                }
                break;
                case digit1:
                {
                    digit1_add(animStates);
                }
                break;
                case digit2:
                {
                    digit2_add(animStates);
                }
                break;
                case digit3:
                {
                    digit3_add(animStates);
                }
                break;
                case IncorrectCharacter:
                {
                    IncorrectCharacter_add(animStates);
                }
                break;
                case SystemSetup:
                {
                    SystemSetup_add(animStates);
                }
                break;
                case Arming:
                {
                    Arming_add(animStates);
                }
                break;
                case InfoDisp:
                {
                    InfoDisp_add(animStates);
                }
                break;
                default:
                    break;
            }
        }
        
        //## statechart_method 
        public void rootState_entDef() {
            {
                rootState_enter();
                rootStateEntDef();
            }
        }
        
        //## statechart_method 
        public int rootState_dispatchEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            switch (rootState_active) {
                case Disarmed:
                {
                    res = Disarmed_takeEvent(id);
                }
                break;
                case Armed:
                {
                    res = Armed_takeEvent(id);
                }
                break;
                case Active:
                {
                    res = Active_takeEvent(id);
                }
                break;
                case digit1:
                {
                    res = digit1_takeEvent(id);
                }
                break;
                case digit2:
                {
                    res = digit2_takeEvent(id);
                }
                break;
                case digit3:
                {
                    res = digit3_takeEvent(id);
                }
                break;
                case IncorrectCharacter:
                {
                    res = IncorrectCharacter_takeEvent(id);
                }
                break;
                case SystemSetup:
                {
                    res = SystemSetup_takeEvent(id);
                }
                break;
                case Arming:
                {
                    res = Arming_takeEvent(id);
                }
                break;
                case InfoDisp:
                {
                    res = InfoDisp_takeEvent(id);
                }
                break;
                default:
                    break;
            }
            return res;
        }
        
        //## statechart_method 
        public void SystemSetup_add(AnimStates animStates) {
            animStates.add("ROOT.SystemSetup");
        }
        
        //## statechart_method 
        public void InfoDisp_add(AnimStates animStates) {
            animStates.add("ROOT.InfoDisp");
        }
        
        //## statechart_method 
        public void IncorrectCharacter_add(AnimStates animStates) {
            animStates.add("ROOT.IncorrectCharacter");
        }
        
        //## statechart_method 
        public void Disarmed_add(AnimStates animStates) {
            animStates.add("ROOT.Disarmed");
        }
        
        //## statechart_method 
        public void digit3_add(AnimStates animStates) {
            animStates.add("ROOT.digit3");
        }
        
        //## statechart_method 
        public void digit2_add(AnimStates animStates) {
            animStates.add("ROOT.digit2");
        }
        
        //## statechart_method 
        public void digit1_add(AnimStates animStates) {
            animStates.add("ROOT.digit1");
        }
        
        //## statechart_method 
        public void Arming_add(AnimStates animStates) {
            animStates.add("ROOT.Arming");
        }
        
        //## statechart_method 
        public void Armed_add(AnimStates animStates) {
            animStates.add("ROOT.Armed");
        }
        
        //## statechart_method 
        public void Active_add(AnimStates animStates) {
            animStates.add("ROOT.Active");
        }
        
        //## auto_generated 
        protected void initStatechart() {
            rootState_subState = RiJNonState;
            rootState_active = RiJNonState;
        }
        
        //## statechart_method 
        public void Arming_enter() {
            animInstance().notifyStateEntered("ROOT.Arming");
            pushNullConfig();
            rootState_subState = Arming;
            rootState_active = Arming;
            ArmingEnter();
        }
        
        //## statechart_method 
        public void digit1_enter() {
            animInstance().notifyStateEntered("ROOT.digit1");
            rootState_subState = digit1;
            rootState_active = digit1;
            digit1Enter();
        }
        
        //## statechart_method 
        public void digit1Enter() {
            //#[ state digit1.(Entry) 
            codeState=1;   
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            System.out.println("**              Alarm system manual             **");
            System.out.println("** Press 'i' to simulate intruder detection     **");
            System.out.println("** Enter 3 digit password to change alarm state **");
            System.out.println("** digits must be entered in separate lines     **");
            System.out.println("** Enter 'x' to exit                            **"); 
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            if(state==1)  
            	System.out.println("**                 Alarm Disarmed               **");
            if(state==2)  
            	System.out.println("**                  Alarm Armed                 **");
            if(state==3)  
            	System.out.println("**                  Alarm Active                **");
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            for(int i=0; i<12; i++)
            	System.out.println("");
            //#]
        }
        
        //## statechart_method 
        public void digit2_enter() {
            animInstance().notifyStateEntered("ROOT.digit2");
            rootState_subState = digit2;
            rootState_active = digit2;
            digit2Enter();
        }
        
        //## statechart_method 
        public int ArmedTakeevIntruderDetected() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("1");
            Armed_exit();
            InfoDisp_entDef();
            animInstance().notifyTransitionEnded("1");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public int ArmingTakeNull() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            //## transition 16 
            if(armingDone)
                {
                    animInstance().notifyTransitionStarted("16");
                    Arming_exit();
                    Armed_entDef();
                    animInstance().notifyTransitionEnded("16");
                    res = RiJStateReactive.TAKE_EVENT_COMPLETE;
                }
            return res;
        }
        
        //## statechart_method 
        public int digit2_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(ev3Digit.ev3Digit_dishwasher_telelogic_com_id))
                {
                    res = digit2Takeev3Digit();
                }
            else if(event.isTypeOf(evIncorrectCharacter.evIncorrectCharacter_dishwasher_telelogic_com_id))
                {
                    res = digit2TakeevIncorrectCharacter();
                }
            
            return res;
        }
        
        //## statechart_method 
        public void digit3_exit() {
            popNullConfig();
            digit3Exit();
            animInstance().notifyStateExited("ROOT.digit3");
        }
        
        //## statechart_method 
        public void digit3_enter() {
            animInstance().notifyStateEntered("ROOT.digit3");
            pushNullConfig();
            rootState_subState = digit3;
            rootState_active = digit3;
            digit3Enter();
        }
        
        //## statechart_method 
        public void SystemSetupExit() {
            //#[ state SystemSetup.(Exit) 
            setup();
            //#]
        }
        
        //## statechart_method 
        public void Active_exit() {
            ActiveExit();
            animInstance().notifyStateExited("ROOT.Active");
        }
        
        //## statechart_method 
        public void digit1_entDef() {
            digit1_enter();
        }
        
        //## statechart_method 
        public void digit2_exit() {
            digit2Exit();
            animInstance().notifyStateExited("ROOT.digit2");
        }
        
        //## statechart_method 
        public void IncorrectCharacterEnter() {
        }
        
        //## statechart_method 
        public void InfoDisp_exit() {
            popNullConfig();
            InfoDispExit();
            animInstance().notifyStateExited("ROOT.InfoDisp");
        }
        
        //## statechart_method 
        public void Armed_entDef() {
            Armed_enter();
        }
        
        //## statechart_method 
        public void digit1_exit() {
            digit1Exit();
            animInstance().notifyStateExited("ROOT.digit1");
        }
        
        //## statechart_method 
        public void Disarmed_enter() {
            animInstance().notifyStateEntered("ROOT.Disarmed");
            rootState_subState = Disarmed;
            rootState_active = Disarmed;
            DisarmedEnter();
        }
        
        //## statechart_method 
        public void ArmedEnter() {
            //#[ state Armed.(Entry) 
            codeState=0;
            state=2;   
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            System.out.println("**              Alarm system manual             **");
            System.out.println("** Press 'i' to simulate intruder detection     **");
            System.out.println("** Enter 3 digit password to change alarm state **");
            System.out.println("** digits must be entered in separate lines     **");
            System.out.println("** Enter 'x' to exit                            **"); 
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            System.out.println("**                  Alarm Armed                 **");
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            for(int i=0; i<12; i++)
            	System.out.println("");
            //#]
        }
        
        //## statechart_method 
        public void ArmingEnter() {
            //#[ state Arming.(Entry) 
            System.out.print((char)(7));	
            String str = "                                              ";   
            char strc[] = str.toCharArray();
            for(int j=0; j<armingProgress; j++){
            	strc[j] = '#';
            }    
            str = String.valueOf(strc);
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            System.out.print("**"); System.out.print(str);System.out.println("**");
            System.out.print("**"); System.out.print(str);System.out.println("**");
            System.out.println("**************************************************");
            System.out.println("**************************************************"); 
            System.out.print("**      Arming: "); 
            System.out.print(46-armingProgress);   
            if(46-armingProgress<10)
            	System.out.print(" ");
            System.out.println(" seconds to exit building     **");
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            for(int j=9; j<24; j++)
            	System.out.println(""); 
            armingProgress++;     
            if(armingProgress>46)
            	armingDone=true;       
            	
            
            	
            //#]
            itsRiJThread.schedTimeout(1000, Alarm_Timeout_Arming_id, this, "ROOT.Arming");
        }
        
        //## statechart_method 
        public int digit3TakeNull() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            //## transition 7 
            if(state!=1)
                {
                    animInstance().notifyTransitionStarted("7");
                    digit3_exit();
                    Disarmed_entDef();
                    animInstance().notifyTransitionEnded("7");
                    res = RiJStateReactive.TAKE_EVENT_COMPLETE;
                }
            else
                {
                    //## transition 8 
                    if(state == 1)
                        {
                            animInstance().notifyTransitionStarted("8");
                            digit3_exit();
                            Arming_entDef();
                            animInstance().notifyTransitionEnded("8");
                            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
                        }
                }
            return res;
        }
        
        //## statechart_method 
        public int IncorrectCharacterTakeNull() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            //## transition 12 
            if(state == 3)
                {
                    animInstance().notifyTransitionStarted("12");
                    IncorrectCharacter_exit();
                    Active_entDef();
                    animInstance().notifyTransitionEnded("12");
                    res = RiJStateReactive.TAKE_EVENT_COMPLETE;
                }
            else
                {
                    //## transition 13 
                    if(state==2)
                        {
                            animInstance().notifyTransitionStarted("13");
                            IncorrectCharacter_exit();
                            Armed_entDef();
                            animInstance().notifyTransitionEnded("13");
                            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
                        }
                    else
                        {
                            //## transition 14 
                            if(state==1)
                                {
                                    animInstance().notifyTransitionStarted("14");
                                    IncorrectCharacter_exit();
                                    Disarmed_entDef();
                                    animInstance().notifyTransitionEnded("14");
                                    res = RiJStateReactive.TAKE_EVENT_COMPLETE;
                                }
                        }
                }
            return res;
        }
        
        //## statechart_method 
        public void IncorrectCharacter_exit() {
            popNullConfig();
            IncorrectCharacterExit();
            animInstance().notifyStateExited("ROOT.IncorrectCharacter");
        }
        
        //## statechart_method 
        public void ActiveExit() {
        }
        
        //## statechart_method 
        public void ArmingExit() {
            itsRiJThread.unschedTimeout(Alarm_Timeout_Arming_id, this);
        }
        
        //## statechart_method 
        public int digit2TakeevIncorrectCharacter() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("10");
            digit2_exit();
            IncorrectCharacter_entDef();
            animInstance().notifyTransitionEnded("10");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public int DisarmedTakeev1Digit() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("2");
            Disarmed_exit();
            digit1_entDef();
            animInstance().notifyTransitionEnded("2");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void IncorrectCharacterExit() {
        }
        
        //## statechart_method 
        public void IncorrectCharacter_entDef() {
            IncorrectCharacter_enter();
        }
        
        //## statechart_method 
        public void InfoDispExit() {
        }
        
        //## statechart_method 
        public void SystemSetup_enter() {
            animInstance().notifyStateEntered("ROOT.SystemSetup");
            rootState_subState = SystemSetup;
            rootState_active = SystemSetup;
            SystemSetupEnter();
        }
        
        //## statechart_method 
        public int rootState_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            return res;
        }
        
        //## statechart_method 
        public int digit1_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(evIncorrectCharacter.evIncorrectCharacter_dishwasher_telelogic_com_id))
                {
                    res = digit1TakeevIncorrectCharacter();
                }
            else if(event.isTypeOf(ev2Digit.ev2Digit_dishwasher_telelogic_com_id))
                {
                    res = digit1Takeev2Digit();
                }
            
            return res;
        }
        
        //## statechart_method 
        public void InfoDisp_entDef() {
            InfoDisp_enter();
        }
        
        //## statechart_method 
        public void Armed_exit() {
            ArmedExit();
            animInstance().notifyStateExited("ROOT.Armed");
        }
        
        //## statechart_method 
        public void Arming_exit() {
            popNullConfig();
            ArmingExit();
            animInstance().notifyStateExited("ROOT.Arming");
        }
        
        //## statechart_method 
        public void Arming_entDef() {
            Arming_enter();
        }
        
        //## statechart_method 
        public void digit2_entDef() {
            digit2_enter();
        }
        
        //## statechart_method 
        public void rootState_enter() {
            animInstance().notifyStateEntered("ROOT");
            rootStateEnter();
        }
        
        //## statechart_method 
        public void rootStateEnter() {
        }
        
        //## statechart_method 
        public int Armed_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(ev1Digit.ev1Digit_dishwasher_telelogic_com_id))
                {
                    res = ArmedTakeev1Digit();
                }
            else if(event.isTypeOf(evIntruderDetected.evIntruderDetected_dishwasher_telelogic_com_id))
                {
                    res = ArmedTakeevIntruderDetected();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int ArmedTakeev1Digit() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("3");
            Armed_exit();
            digit1_entDef();
            animInstance().notifyTransitionEnded("3");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public int digit1Takeev2Digit() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("5");
            digit1_exit();
            digit2_entDef();
            animInstance().notifyTransitionEnded("5");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public int Active_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(ev1Digit.ev1Digit_dishwasher_telelogic_com_id))
                {
                    res = ActiveTakeev1Digit();
                }
            
            return res;
        }
        
        //## statechart_method 
        public void ArmedExit() {
        }
        
        //## statechart_method 
        public int InfoDisp_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(RiJEvent.NULL_EVENT_ID))
                {
                    res = InfoDispTakeNull();
                }
            
            return res;
        }
        
        //## statechart_method 
        public void Active_entDef() {
            Active_enter();
        }
        
        //## statechart_method 
        public void SystemSetupEnter() {
            //#[ state SystemSetup.(Entry) 
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            System.out.println("**                  Alarm system                **");
            System.out.println("**                                              **");
            System.out.println("**             by Michal Frankiewicz            **");
            System.out.println("**                                              **");
            System.out.println("** Enter 'i' to simulate intruder detection     **");
            System.out.println("** Enter 3 digit password to change alarm state **");
            System.out.println("** digits must be entered in separate lines     **");
            System.out.println("** Enter 'x' to exit                            **"); 
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            System.out.println("**            Enter 's' to continue             **");
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            //#]
        }
        
        //## statechart_method 
        public void rootStateEntDef() {
            animInstance().notifyTransitionStarted("0");
            SystemSetup_entDef();
            animInstance().notifyTransitionEnded("0");
        }
        
        //## statechart_method 
        public void Active_enter() {
            animInstance().notifyStateEntered("ROOT.Active");
            rootState_subState = Active;
            rootState_active = Active;
            ActiveEnter();
        }
        
        //## statechart_method 
        public int Arming_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(RiJEvent.NULL_EVENT_ID))
                {
                    res = ArmingTakeNull();
                }
            else if(event.isTypeOf(RiJEvent.TIMEOUT_EVENT_ID))
                {
                    res = ArmingTakeRiJTimeout();
                }
            
            return res;
        }
        
        //## statechart_method 
        public void InfoDisp_enter() {
            animInstance().notifyStateEntered("ROOT.InfoDisp");
            pushNullConfig();
            rootState_subState = InfoDisp;
            rootState_active = InfoDisp;
            InfoDispEnter();
        }
        
        //## statechart_method 
        public int ActiveTakeev1Digit() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("4");
            Active_exit();
            digit1_entDef();
            animInstance().notifyTransitionEnded("4");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public int ArmingTakeRiJTimeout() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.getTimeoutId() == Alarm_Timeout_Arming_id)
                {
                    animInstance().notifyTransitionStarted("17");
                    Arming_exit();
                    Arming_entDef();
                    animInstance().notifyTransitionEnded("17");
                    res = RiJStateReactive.TAKE_EVENT_COMPLETE;
                }
            return res;
        }
        
        //## statechart_method 
        public void digit1Exit() {
        }
        
        //## statechart_method 
        public int digit3_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(RiJEvent.NULL_EVENT_ID))
                {
                    res = digit3TakeNull();
                }
            else if(event.isTypeOf(evIncorrectCharacter.evIncorrectCharacter_dishwasher_telelogic_com_id))
                {
                    res = digit3TakeevIncorrectCharacter();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int digit3TakeevIncorrectCharacter() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("11");
            digit3_exit();
            IncorrectCharacter_entDef();
            animInstance().notifyTransitionEnded("11");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void DisarmedEnter() {
            //#[ state Disarmed.(Entry) 
            codeState=0;
            state=1;
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            System.out.println("**              Alarm system manual             **");
            System.out.println("** Press 'i' to simulate intruder detection     **");
            System.out.println("** Enter 3 digit password to change alarm state **");
            System.out.println("** digits must be entered in separate lines     **"); 
            System.out.println("** Enter 'x' to exit                            **");
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            System.out.println("**                Alarm Disarmed                **");
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            for(int i=0; i<12; i++)
            	System.out.println("");
            //#]
        }
        
        //## statechart_method 
        public void IncorrectCharacter_enter() {
            animInstance().notifyStateEntered("ROOT.IncorrectCharacter");
            pushNullConfig();
            rootState_subState = IncorrectCharacter;
            rootState_active = IncorrectCharacter;
            IncorrectCharacterEnter();
        }
        
        //## statechart_method 
        public void SystemSetup_entDef() {
            SystemSetup_enter();
        }
        
        //## statechart_method 
        public void Armed_enter() {
            animInstance().notifyStateEntered("ROOT.Armed");
            rootState_subState = Armed;
            rootState_active = Armed;
            ArmedEnter();
        }
        
        //## statechart_method 
        public int digit2Takeev3Digit() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("6");
            digit2_exit();
            digit3_entDef();
            animInstance().notifyTransitionEnded("6");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void digit2Exit() {
        }
        
        //## statechart_method 
        public void digit3_entDef() {
            digit3_enter();
        }
        
        //## statechart_method 
        public int Disarmed_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(ev1Digit.ev1Digit_dishwasher_telelogic_com_id))
                {
                    res = DisarmedTakeev1Digit();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int IncorrectCharacter_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(RiJEvent.NULL_EVENT_ID))
                {
                    res = IncorrectCharacterTakeNull();
                }
            
            return res;
        }
        
        //## statechart_method 
        public void SystemSetup_exit() {
            SystemSetupExit();
            animInstance().notifyStateExited("ROOT.SystemSetup");
        }
        
        //## statechart_method 
        public void rootStateExit() {
        }
        
        //## statechart_method 
        public int digit1TakeevIncorrectCharacter() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("9");
            digit1_exit();
            IncorrectCharacter_entDef();
            animInstance().notifyTransitionEnded("9");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void digit3Exit() {
            //#[ state digit3.(Exit) 
            armingDone = false; 
            armingProgress = 0;
            //#]
        }
        
        //## statechart_method 
        public void digit3Enter() {
            //#[ state digit3.(Entry) 
            codeState=3;                 
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            System.out.println("**              Alarm system manual             **");
            System.out.println("** Press 'i' to simulate intruder detection     **");
            System.out.println("** Enter 3 digit password to change alarm state **");
            System.out.println("** digits must be entered in separate lines     **");
            System.out.println("** Enter 'x' to exit                            **"); 
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            if(state==1)  
            	System.out.println("**                 Alarm Disarmed               **");
            if(state==2)  
            	System.out.println("**                  Alarm Armed                 **");
            if(state==3)  
            	System.out.println("**                  Alarm Active                **");
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            for(int i=0; i<12; i++)
            	System.out.println("");
            //#]
        }
        
        //## statechart_method 
        public int InfoDispTakeNull() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("18");
            InfoDisp_exit();
            Active_entDef();
            animInstance().notifyTransitionEnded("18");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public int SystemSetup_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(evSystemStart.evSystemStart_dishwasher_telelogic_com_id))
                {
                    res = SystemSetupTakeevSystemStart();
                }
            
            return res;
        }
        
        //## statechart_method 
        public void ActiveEnter() {
            //#[ state Active.(Entry) 
            codeState=0;
            state=3;           
            for(int i=0; i<10; i++)
            	System.out.print((char)(7));
            //#]
        }
        
        //## statechart_method 
        public void digit2Enter() {
            //#[ state digit2.(Entry) 
            codeState=2;     
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            System.out.println("**              Alarm system manual             **");
            System.out.println("** Press 'i' to simulate intruder detection     **");
            System.out.println("** Enter 3 digit password to change alarm state **");
            System.out.println("** digits must be entered in separate lines     **");
            System.out.println("** Enter 'x' to exit                            **"); 
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            if(state==1)  
            	System.out.println("**                 Alarm Disarmed               **");
            if(state==2)  
            	System.out.println("**                  Alarm Armed                 **");
            if(state==3)  
            	System.out.println("**                  Alarm Active                **");
            System.out.println("**************************************************");
            System.out.println("**************************************************");  
            for(int i=0; i<12; i++)
            	System.out.println("");
            //#]
        }
        
        //## statechart_method 
        public void Disarmed_exit() {
            DisarmedExit();
            animInstance().notifyStateExited("ROOT.Disarmed");
        }
        
        //## statechart_method 
        public void DisarmedExit() {
        }
        
        //## statechart_method 
        public void Disarmed_entDef() {
            Disarmed_enter();
        }
        
        //## statechart_method 
        public void InfoDispEnter() {
            //#[ state InfoDisp.(Entry) 
            codeState=0;
            state=3;
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            System.out.println("**              Alarm system manual             **");
            System.out.println("** Press 'i' to simulate intruder detection     **");
            System.out.println("** Enter 3 digit password to change alarm state **");
            System.out.println("** digits must be entered in separate lines     **"); 
            System.out.println("** Enter 'x' to exit                            **"); 
            System.out.println("**************************************************"); 
            System.out.println("**************************************************");  
            System.out.println("**               Intruder detected              **");
            System.out.println("**************************************************");
            System.out.println("**************************************************");
            for(int i=0; i<12; i++)
            	System.out.println("");
            //#]
        }
        
        //## statechart_method 
        public int SystemSetupTakeevSystemStart() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("15");
            SystemSetup_exit();
            Disarmed_entDef();
            animInstance().notifyTransitionEnded("15");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        /**  methods added just for design level debugging instrumentation */
        public boolean startBehavior() {
            try {
              animInstance().notifyBehavioralMethodEntered("startBehavior",
                  new ArgData[] {
                   });
              return super.startBehavior();
            }
            finally {
              animInstance().notifyMethodExit();
            }
        }
        public int takeEvent(RiJEvent event) { 
            try { 
              //animInstance().notifyTakeEvent(new AnimEvent(event));
              animInstance().notifyBehavioralMethodEntered("takeEvent",
                  new ArgData[] { new ArgData(RiJEvent.class, "event", event.toString())
                   });
              return super.takeEvent(event); 
            }
            finally { 
              animInstance().notifyMethodExit();
            }
        }
        /**  see com.ibm.rational.rhapsody.animation.AnimatedReactive interface */
        public AnimInstance animInstance() { 
            return Alarm.this.animInstance(); 
        }
        
    }
    //#[ ignore
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimClass getAnimClass() { 
        return animClassAlarm; 
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimInstance animInstance() {
        if (animate == null) 
            animate = new Animate(); 
        return animate; 
    } 
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addAttributes(AnimAttributes msg) {
        
        msg.add("state", state);
        msg.add("codeState", codeState);
        msg.add("armingDone", armingDone);
        msg.add("armingProgress", armingProgress);
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addRelations(AnimRelations msg) {
        
        msg.add("itsDisplay", false, true, itsDisplay);
    }
    /** An inner class added as instrumentation for animation */
    public class Animate extends AnimInstance { 
        public  Animate() { 
            super(Alarm.this); 
        } 
        public void addAttributes(AnimAttributes msg) {
            Alarm.this.addAttributes(msg);
        }
        public void addRelations(AnimRelations msg) {
            Alarm.this.addRelations(msg);
        }
        
        public void addStates(AnimStates msg) {
            if ((reactive != null) && (reactive.isTerminated() == false))
              reactive.rootState_add(msg);
        }
        
    } 
    //#]
    
}
/*********************************************************************
	File Path	: EXE/Host/com/telelogic/dishwasher/Alarm.java
*********************************************************************/

