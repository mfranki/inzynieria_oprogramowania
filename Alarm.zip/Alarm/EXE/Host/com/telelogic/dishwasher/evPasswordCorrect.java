/*********************************************************************
	Rhapsody	: 8.3.1
	Login		: student
	Component	: EXE
	Configuration 	: Host
	Model Element	: evPasswordCorrect
//!	Generated Date	: Thu, 23, May 2019 
	File Path	: EXE/Host/com/telelogic/dishwasher/evPasswordCorrect.java
*********************************************************************/

package com.telelogic.dishwasher;

//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.RiJEvent;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// com/telelogic/dishwasher/evPasswordCorrect.java                                                                  
//----------------------------------------------------------------------------

//## package com::telelogic::dishwasher 


//## event evPasswordCorrect() 
public class evPasswordCorrect extends RiJEvent implements AnimatedEvent {
    
    public static final int evPasswordCorrect_dishwasher_telelogic_com_id = 6623;		//## ignore 
    
    
    // Constructors
    
    public  evPasswordCorrect() {
        lId = evPasswordCorrect_dishwasher_telelogic_com_id;
    }
    
    public boolean isTypeOf(long id) {
        return (evPasswordCorrect_dishwasher_telelogic_com_id==id);
    }
    
    //#[ ignore
    /** the animated event proxy */
    public static AnimEventClass animClass = new AnimEventClass("com.telelogic.dishwasher.evPasswordCorrect");
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public void addAttributes(AnimAttributes msg) {      
    }
    public String toString() {
          String s="evPasswordCorrect(";      
          s += ")";
          return s;
    }
    //#]
    
}
/*********************************************************************
	File Path	: EXE/Host/com/telelogic/dishwasher/evPasswordCorrect.java
*********************************************************************/

