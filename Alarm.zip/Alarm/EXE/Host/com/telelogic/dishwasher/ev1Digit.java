/*********************************************************************
	Rhapsody	: 8.3.1
	Login		: student
	Component	: EXE
	Configuration 	: Host
	Model Element	: ev1Digit
//!	Generated Date	: Thu, 23, May 2019 
	File Path	: EXE/Host/com/telelogic/dishwasher/ev1Digit.java
*********************************************************************/

package com.telelogic.dishwasher;

//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.RiJEvent;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// com/telelogic/dishwasher/ev1Digit.java                                                                  
//----------------------------------------------------------------------------

//## package com::telelogic::dishwasher 


//## event ev1Digit() 
public class ev1Digit extends RiJEvent implements AnimatedEvent {
    
    public static final int ev1Digit_dishwasher_telelogic_com_id = 6624;		//## ignore 
    
    
    // Constructors
    
    public  ev1Digit() {
        lId = ev1Digit_dishwasher_telelogic_com_id;
    }
    
    public boolean isTypeOf(long id) {
        return (ev1Digit_dishwasher_telelogic_com_id==id);
    }
    
    //#[ ignore
    /** the animated event proxy */
    public static AnimEventClass animClass = new AnimEventClass("com.telelogic.dishwasher.ev1Digit");
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public void addAttributes(AnimAttributes msg) {      
    }
    public String toString() {
          String s="ev1Digit(";      
          s += ")";
          return s;
    }
    //#]
    
}
/*********************************************************************
	File Path	: EXE/Host/com/telelogic/dishwasher/ev1Digit.java
*********************************************************************/

