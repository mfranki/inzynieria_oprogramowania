/*********************************************************************
	Rhapsody	: 8.3.1
	Login		: student
	Component	: EXE
	Configuration 	: Host
	Model Element	: Host
//!	Generated Date	: Thu, 23, May 2019 
	File Path	: EXE/Host/MainEXE.java
*********************************************************************/


//## auto_generated
import com.telelogic.dishwasher.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.*;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.*;

//----------------------------------------------------------------------------
// MainEXE.java                                                                  
//----------------------------------------------------------------------------


//## ignore 
public class MainEXE {
    
    //#[ ignore
    // link with events in order to register them in the animation browser
    static {
      // Setting Animation Default Port 
      AnimTcpIpConnection.setDefaultPort(6423);
      // Registering Events 
      try {
        
            Class.forName("com.telelogic.dishwasher.e");
            Class.forName("com.telelogic.dishwasher.ev1Digit");
            Class.forName("com.telelogic.dishwasher.ev2Digit");
            Class.forName("com.telelogic.dishwasher.ev3Digit");
            Class.forName("com.telelogic.dishwasher.evClose");
            Class.forName("com.telelogic.dishwasher.eventmessage_0");
            Class.forName("com.telelogic.dishwasher.evIncorrectCharacter");
            Class.forName("com.telelogic.dishwasher.evIntruderDetected");
            Class.forName("com.telelogic.dishwasher.evKeyPress");
            Class.forName("com.telelogic.dishwasher.evOpen");
            Class.forName("com.telelogic.dishwasher.evPasswordCorrect");
            Class.forName("com.telelogic.dishwasher.evStart");
            Class.forName("com.telelogic.dishwasher.evSystemStart");
    
        // Registering Static Classes 
        
      }
      catch(Exception e) { 
         java.lang.System.err.println(e.toString());
         e.printStackTrace(java.lang.System.err);
      }
    }
    //#]
    
    protected static AlarmBuilder p_AlarmBuilder = null;
    
    //## configuration EXE::Host 
    public static void main(String[] args) {
        RiJOXF.Init(null, 0, 0, true, args);
        MainEXE initializer_EXE = new MainEXE();
        p_AlarmBuilder = new AlarmBuilder(RiJMainThread.instance());
        p_AlarmBuilder.startBehavior();
        //#[ configuration EXE::Host 
        //#]
        RiJOXF.Start();
        p_AlarmBuilder=null;
    }
    
}
/*********************************************************************
	File Path	: EXE/Host/MainEXE.java
*********************************************************************/

